package AutomationExcercies;

public class Soru8 {
    /*
    1. Tarayıcıyı başlatın
2. 'http://automationexercise.com' url'sine gidin
3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
4. 'Ürünler' düğmesine tıklayın
5. Kullanıcının TÜM ÜRÜNLER sayfasına başarıyla gittiğini doğrulayın
6. Ürün listesi görünür
7. İlk ürünün 'Ürünü Görüntüle'ye tıklayın
8. Kullanıcı, ürün detay sayfasına yönlendirilir
9. Ayrıntıların görünür olduğunu doğrulayın: ürün adı, kategori, fiyat, bulunabilirlik, durum, marka
     */
}
