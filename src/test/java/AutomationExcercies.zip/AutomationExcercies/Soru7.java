package AutomationExcercies;

public class Soru7 {
    /*
    1. Tarayıcıyı başlatın
2. 'http://automationexercise.com' url'sine gidin
3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
4. 'Test Vakaları' düğmesine tıklayın
5. Kullanıcının test senaryoları sayfasına başarıyla yönlendirildiğini doğrulayın
     */
}
