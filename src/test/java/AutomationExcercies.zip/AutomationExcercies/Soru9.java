package AutomationExcercies;

public class Soru9 {
    /*
    1. Tarayıcıyı başlatın
2. 'http://automationexercise.com' url'sine gidin
3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
4. 'Ürünler' düğmesine tıklayın
5. Kullanıcının TÜM ÜRÜNLER sayfasına başarıyla gittiğini doğrulayın
6. Arama girişine ürün adını girin ve ara düğmesine tıklayın
7. 'ARARAN ÜRÜNLER'in görünür olduğunu doğrulayın
8. Aramayla ilgili tüm ürünlerin görünür olduğunu doğrulayın
     */
}
