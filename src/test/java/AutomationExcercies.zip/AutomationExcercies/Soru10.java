package AutomationExcercies;

public class Soru10 {
    /*
    1. Tarayıcıyı başlatın
    2. 'http://automationexercise.com' url'sine gidin
    3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
    4. Altbilgiye ilerleyin
    5. 'ABONELİK' metnini doğrulayın
    6. Girişe e-posta adresini girin ve ok düğmesine tıklayın
    7. Başarı mesajını doğrulayın 'Başarıyla abone oldunuz!' görünür
     */
}
