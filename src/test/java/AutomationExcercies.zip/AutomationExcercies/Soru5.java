package AutomationExcercies;

public class Soru5 {
    /*
    1. Tarayıcıyı başlatın
2. 'http://automationexercise.com' url'sine gidin
3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
4. 'Kayıt Ol / Giriş Yap' düğmesine tıklayın
5. 'Yeni Kullanıcı Kaydı'nı doğrulayın! görünür
6. Adı ve kayıtlı e-posta adresini girin
7. 'Kaydol' düğmesini tıklayın
8. 'E-posta Adresi zaten var!' hatasını doğrulayın. görünür
     */
}
