package AutomationExcercies;

public class Soru2 {
    /*
    1. Tarayıcıyı başlatın
    2. 'http://automationexercise.com' url'sine gidin
    3. Ana sayfanın başarıyla görünür olduğunu doğrulayın
    4. 'Kayıt Ol / Giriş Yap' düğmesine tıklayın
    5. 'Hesabınıza giriş yapın' ifadesinin görünür olduğunu doğrulayın
    6. Doğru e-posta adresini ve şifreyi girin
    7. 'Giriş' düğmesini tıklayın
    8. 'Kullanıcı adı olarak oturum açıldı' ifadesinin görünür olduğunu doğrulayın
    9. 'Hesabı Sil' düğmesini tıklayın
    10. 'HESAP SİLİNDİ!' görünür oldugunu dogrulayin
     */
}
